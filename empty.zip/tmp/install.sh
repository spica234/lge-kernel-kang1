#!/sbin/sh
device=LGP990

ui_print() {
    echo ui_print "$@" 1>&$UPDATE_CMD_PIPE;
    if [ -n "$@" ]; then
        echo ui_print 1>&$UPDATE_CMD_PIPE;
    fi
}
log () { echo "$@"; }
fatal() { ui_print "$@"; exit 1; }

bd="/tmp"
BB=$bd/busybox
sed="$BB sed"
grep="$BB grep"
chmod="$BB chmod"
chown="$BB chown"

ui_print "#############################################"
ui_print "#                                           #"
ui_print "#           LGE Kernel Installer            #"
ui_print "#                                           #"
ui_print "#            rewrite by vadonka             #"
ui_print "#                                           #"
ui_print "#############################################"
ui_print ""
ui_print ""
ui_print "***        Installing LGE kernel Kang     ***"
ui_print "***         Based on lge-kernel-star      ***"
ui_print "***              by the CM team           ***"
ui_print ""
ui_print "*** compiled and cherry picked by vadonka ***"
ui_print ""

ui_print "Checking ROM..." 

cyanogen=`$grep -c "cyanogenmod" /system/build.prop`
miui=`$grep -c "miui" /system/build.prop`
grj22=`$grep -c "GRJ22" /system/build.prop`

if [ "$cyanogen" == "1" ]; then
    log "Installing on CyanogenMod"
elif [ "$miui" == "1" ]; then
    log "Installing on Miui"
elif [ "$grj22" == "1" ]; then
	log "Installing on MIUI or CM7 custom build"
else
    fatal "Current ROM is not compatible with LGE kernel! Aborting..."
fi

if [ -e /system/build.prop.aiotweak ]; then
	ui_print ""
	ui_print "Removing old build.prop backup."
	rm /system/build.prop.aiotweak
fi

ui_print "Backup build.prop."	
cp /system/build.prop /system/build.prop.aiotweak

ui_print ""
ui_print "Applying build.prop tweaks..."

# Build prop modify procedure, dont touch!
##########################################
add()
{
	pcheck=`$grep -c "$1" /system/build.prop`
	orig=`$grep "$1$2" /system/build.prop`
	mod=`echo $1$2$3`
	if [ "$pcheck" -gt "0" ]; then
		$sed -i "s/$orig/$mod/g" /system/build.prop
	else
		echo $mod >> /system/build.prop
	fi
}

############################################
# build.prop tweaks, changeable            #
# Make sure that you dont delete           #
# white space before and after the equals! #
############################################
# General
add ro.wifi.channels = 14
add dalvik.vm.heapsize = 48m
add ro.telephony.call_ring.delay = 1000
# Bravia engine
add ro.service.swiqi.supported = true
add persist.service.swiqi.enable = 1
# Battery save
add wifi.supplicant_scan_interval = 320
add pm.sleep_mode = 1
add ro.ril.disable.power.collapse = 0
# Helps scrolling responsiveness
add windowsmgr.max_events_per_sec = 150
# Fix BSOD issue after a call
add ro.lge.proximity.delay = 25
# CM7 tweak
add persist.sys.use_dithering = 0
add persist.sys.purgeable_assets = 1
# Render UI with GPU
add debug.sf.hw = 1
# Increase overall touch responsiveness
add debug.performance.tuning = 1
add video.accelerate.hw = 1
# Phone will not wake up from hitting the volume rocker
add ro.config.hwfeature_wakeupkey = 0
# Fix some application issues
add ro.kernel.android.checkjni = 0
# Network speed tweak
add ro.ril.hsxpa = 2
add ro.ril.gprsclass = 10
add ro.ril.hep = 1
add ro.ril.enable.dtm = 1
add ro.ril.hsdpa.category = 10
add ro.ril.enable.a53 = 1
add ro.ril.enable.3g.prefix = 1
add ro.ril.htcmaskw1 = 14449
add ro.ril.htcmaskw1.bitmask = 4294967295
add ro.ril.hsupa.category = 5 
add net.tcp.buffersize.default = 4096,87380,256960,4096,16384,256960
add net.tcp.buffersize.wifi = 4096,87380,256960,4096,16384,256960
add net.tcp.buffersize.umts = 4096,87380,256960,4096,16384,256960
add net.tcp.buffersize.edge = 4096,87380,256960,4096,16384,256960
# Disable the setup wizard
add ro.setupwizard.mode = DISABLED

# Kernel flashing
ui_print ""
ui_print "Flashing the kernel..."
$BB dd if=/dev/zero of=/dev/block/mmcblk0p5
$BB dd if=$bd/boot.img of=/dev/block/mmcblk0p5
if [ "$?" -ne 0 ]; then
    fatal "ERROR: Flashing kernel failed!"
fi

# Cleanup process
ui_print ""
ui_print "Cleaning up..."
rm /system/lib/modules/*
rm /system/etc/init.d/*
rm -rf /data/dalvik-cache/*

# Leave the rest to the CWM